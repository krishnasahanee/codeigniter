<?php
include("conn.php");
if(isset($_REQUEST['submit']))
{
    $u=$_REQUEST['uname'];
    $p=$_REQUEST['pass'];
    $g=$_REQUEST['gender'];  
    $h=$_REQUEST['hby'];
    $hh=implode(",",$h);
    $co=$_REQUEST['country'];
    $ins="insert into reg(uname,pass,gender,hobby,country) values('$u','$p','$g','$hh','$co')";
    $ex=$conn->query($ins);
}

?>
<html>
    <head>
        <title> Online Registration </title>
    </head>
    <body>
        <h1 align="center"><U>Registration Form</U></h1>
        <form method="post">
            <table align="center" border="1">
                <tr>
                    <td>User Name</td>
                    <td><input type="text" name="uname" /></td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td><input type="password" name="pass" /></td>
                </tr>
                <tr>
                    <td>Gender</td>
                    <td><input type="radio" name="gender" value="Male">Male
                    <input type="radio" name="gender" value="Female">Female </td>
                </tr>
                <tr>
                    <td>Hobby</td>
                    <td>
                        <input type="checkbox" name="hby[]" value="Read"/>Read
                    <input type="checkbox" name="hby[]" value="Write">Write
                    </td>
                </tr>
                <tr> 
                    <td>Country</td>
                    <td>
                       <?php
                            $sel=" select * from country";
                            $ex=$conn->query($sel);
                            ?>
                         <select name="country">
                             <option value="Select">Select</option>
                            <?php
                             while($rr=$ex->fetch_object())
                            {
                                
                        ?>
                            <option value="<?php echo $rr->cid; ?>"><?php echo $rr->cname; ?></option>
                            <?php
                             }
                            ?>
                        </select></td>
                </tr>
                <tr>
                    <td align="center" colspan="2">
                        <input type="submit" name="submit" value="Send">
                    </td>
                </tr>
            </table>
            <center><b>Already registerd</b><br><a href="login.php">Login Here</a></center>
        </form>
           
    </body>
</html>


