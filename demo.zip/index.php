<?php  
session_start();  
if(!$_SESSION['uname'])  
{  
  
    header("location:login.php");//redirect to login page to secure the welcome page without login access.  
}  
  
?>  
<?php
include("conn.php");
$sel="select * from reg join country on reg.country=country.cid order by uid";
$ex=$conn->query($sel);
?>
<html>
    <head>
        <title>View data</title>
    </head>
    <body>
        <h1 align="center"><u>Data viewing</u></h1>
        <form method="post">
            <table align="center" border="1">
                <tr>
                    <th>#</th>
                    <th>Uid</th>
                    <th>UserName</th>
                    <th>Password</th>
                    <th>Gender</th>
                    <th>Hobby</th>
                    <th>Country</th>
                    <th>Status</th>
                    <th align="center" colspan="2">Action</th>
                </tr>
                <?php
               
                while($r=$ex->fetch_object())
                {
                ?>
                <tr>
                    <td><input type="checkbox" name="hby" value="<?php echo $r->uid;?>"/></td>
                    
                    <td><?php echo $r->uid;?></td>
                    <td><?php echo $r->uname;?></td>
                    <td><?php echo $r->pass;?></td>
                    <td><?php echo $r->gender;?></td>
                    <td><?php echo $r->hobby;?></td>
                    <td><?php echo $r->cname;?></td>
                    <td><a href="index.php?st_id=<?php echo $r->uid;?>&&sts=<?php echo $r->status;?>"><?php echo $r->status;?></a></td>
                    <td><a href="index.php?del_id=<?php echo $r->uid;?>">Delete</a></td>                
                    <td><a href="reg.php?edit_id=<?php echo $r->uid;?>">Edit</a></td>
                </tr>
                <?php
                }
                ?>
                <?php
            
            if(isset($_REQUEST['st_id']))
            {
            $id=$_REQUEST['st_id'];
            $sts=$_REQUEST['sts'];
           
            if($sts=="Active")
                {
                $upd="update reg set status='Block' where uid='$id'";
                $ex=$conn->query($upd);
                header("location:index.php");
                }
            else if($sts=="Block")
                {
                $upd="update reg set status='Active' where uid='$id'";
                $ex=$conn->query($upd);
                header("location:index.php");
                }
                
             }
            
            ?>
                <tr>
                    <td><input type="submit" name="del" value="delete"/></td>
                </tr>
            
            </table>
                <center><h3><a href="logout.php">Logout</a></h3></center>
        </form>
    </body>
</html>
<?php
      if(isset($_REQUEST['del_id']))
                {
                    $d=$_REQUEST['del_id'];
                    $del="delete from reg where uid='$d'";  
                    $ex=$conn->query($del);
                    header('location:index.php');
                    
                }
?>
