<?php
include "cn.php";
?>
<html>
    <head>
        <title>Country</title>
    </head>
    <body>
        <h1 align="center"><u>Country list</u></h1>
        <form method="post">
            <table align="center" border="1">
                <tr>
                    <td>Country</td>
                    <td>
                        <?php
                        $sel="select * from country";
                        $ex=$conn->query($sel);
                        ?>
                        <select name="country">
                            <option value="select">select</option>
                            <?php
                            while($r=$ex->fetch_object())
                            {
                            ?>
                            <option value="<?php echo "$r->cid"; ?>"><?php echo "$r->cname"; ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td align="center" colspan="2"><input type="submit" name="submit" value="insert"></td>
                </tr>
            </table>
        </form>
    </body>
</html>