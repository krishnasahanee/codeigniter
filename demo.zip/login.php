<?php
session_start();
include ("conn.php");
if(isset($_REQUEST['login']))
{
    $u=$_REQUEST['uname'];
    $p=$_REQUEST['pass'];
    $sel="select * from reg where uname='$u' and pass='$p'";
    $qq=$conn->query($sel);
    $num=$qq->num_rows;
    
    if(!$num>0)
    {
      
       $msg="<h3 align= 'center'>Worng Username and Password......!!!!</h3>";
    
    }
    else
    { 
        
        header("location:index.php");
        $_SESSION['uname']=$u;
    }
}

?>
<html>
    <head>
        <title>Login Page</title>
    </head>
    <body>
        <h1 align="center"><U>Login Here</U></h1>
        
        <?php
            if(isset($_REQUEST['login']))
            {
                echo $msg;
            }
        ?>
        
        <form method="post">
            <table  align="center" border="1">
                 
                <tr>
                    <td>Username</td>
                    <td><input type="text" name="uname"></td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td><input type="password" name="pass"></td>
                </tr>
                <tr>
                    <td align="center" colspan="2"><input type="submit" name="login" value="Login"></td>
                </tr>
            </table>
        </form>
       <center><b>Not registerd yet !</b><br><a href="reg.php">Click Here</a></center> 
        
    </body>
</html>
