<?php
    
if(isset($_REQUEST['submit']))
{
    $u=$_REQUEST['uname'];
    $p=$_REQUEST['pass'];
    $g=$_REQUEST['gender'];  
    $h=$_REQUEST['hby'];
    $hh=implode(",",$h);
    $co=$_REQUEST['country'];
    $ins="insert into reg(uname,pass,gender,hobby,country) values('$u','$p','$g','$hh','$co')";
    $ex=$conn->query($ins);
}

?>
<?php
/*fetch the data from the database for update*/
if(isset($_REQUEST['edit_id']))
{
    $ed=$_REQUEST['edit_id'];
    $sel="select * from reg where uid='$ed' ";
    $ex=$conn->query($sel);
    $r=$ex->fetch_object();

if(isset($_REQUEST['update']))
{
   
    $u=$_REQUEST['uname'];
    $p=$_REQUEST['pass'];
    $g=$_REQUEST['gender'];
    $h=$_REQUEST['hby'];
    $hh=implode(",",$h);
    $co=$_REQUEST['country'];
    $up="update reg set uname='$u',pass='$p',gender='$g',hobby='$hh',country='$co' where uid='$e'";
    $conn->query($up);
    header("location:index.php");
}
}
?>
<html>
    <head>
        <title> Online Registration </title>
    </head>
    <body>
        <h1 align="center"><U>Registration Form</U></h1>
        <form method="post">
            <table align="center" border="1">
                <tr>
                    <td>User Name</td>
                    <td><input type="text" name="uname" value="<?php if(isset($_REQUEST['edit_id'])){ echo $r->uname;}?>"/></td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td><input type="text" name="pass" value="<?php if(isset($_REQUEST['edit_id'])){ echo $r->pass;}?>"/></td>
                </tr>
                <tr>
                    <td>Gender</td>
                    <td><input type="radio" name="gender" value="Male"
                               <?php
                               
                               if(isset($_REQUEST['edit_id']))
                               {
                                   
                                   if($r->gender=='male')
                                   {
                                       echo "checked";
                                   }
                               }  
                               ?>
                               >Male
                    <input type="radio" name="gender" value="Female"
                           <?php
                            if($r->gender=='female')
                               {
                                   echo "checked";
                               }
                           
                           ?>
                           >Female </td>
                </tr>
                <tr>
                    <td>Hobby</td>
                    <td>
                        <?php
                        if(isset($_REQUEST['edit_id']))
                        {
                            $t=$r->hobby;
                            $h=explode(",",$t);
                        }
                        ?>
                        <input type="checkbox" name="hby[]" value="Read"
                               <?php
                               if(isset($_REQUEST['edit_id']))
                               {
                                   if($h[0]=='read')
                                   {
                                       echo "checked='checked'";
                                   }
                               }
                               ?>
                               />Read
                    <input type="checkbox" name="hby[]" value="Write"
                           <?php
                           if(isset($_REQUEST['edit_id']))
                           {
                               if($h[0]=='write' )
                               {
                                   echo "checked='checked'";
                               }
                           }
                           ?>
                           >Write
                    </td>
                </tr>
                <tr> 
                    <td>Country</td>
                    <td>
                        <select name="country">
                        <?php
                            $sel=" select * from country";
                            $ex=$conn->query($sel);
                            while($rr=$ex->fetch_object())
                            {
                                if($r->country==$rr->cid)
                                {
                        ?>
                            <option value="<?php echo $rr->cid; ?>"><?php echo $rr->cname; ?></option>
                            <?php
                            }
                                else
                                {
                            ?>
                            <option value="<?php echo $rr->cid; ?>"><?php echo $rr->cname; ?></option>
                            <?php
                                }
                            }
                            ?>
                        </select></td>
                </tr>
                <tr>
                    <td align="center" colspan="2">
                        <input type="submit" name="update" value="Send">
                    </td>
                </tr>
            </table>
            <center><b>Already registerd</b><br><a href="login.php">Login Here</a></center>
        </form>
           
    </body>
</html>
